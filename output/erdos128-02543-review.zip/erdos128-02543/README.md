# Sparse halves: revised manuscript and computational materials

The enclosed manuscript proposes the bound 0.02543 n^2. The original
0.02 n^2 problem remains unresolved. The author, komeiji shiki, has
confirmed review of the mathematical arguments, cited-result applicability
and computational checks. This is the author's declaration, not an
independent peer-review endorsement. The work remains an AI-assisted draft
and research priority has not been established.
A subsequent AI-assisted audit of the written proof is recorded in
notes/proof-audit-2026-09-05.md (Chinese). The later author declaration is
recorded in results/author-review-status.json. Contact details and the
journal's acceptance of the pseudonym remain pending.

Run the numerical checks from this directory using Python 3.11 or later:

    python -S src/verify_paper.py

Only the Python standard library is required. This checks five rational
interval certificates using two separate implementations and expands the
cited four-cycle certificate. The second interval implementation imports
no other project modules. Both use exact rational arithmetic. The written
graph-theoretic reductions and the quoted Balogh-Clemen-Lidicky max-cut
and Razborov large-independence theorems remain separate mathematical
obligations. The program explicitly reports its scope.
Computer-generated reports do not evaluate whether a human performed a
review; their human-review flags are not the current author-status record.

The second interval checker and the supplied negative-control tests can
also be run separately, without third-party packages:

    python -S src/audit_intervals.py
    python -S -m unittest discover -s tests -v

This focused archive includes three tests; the full research workspace
passed 17 tests. The latter also exercise earlier finite-graph work and
require the workspace's third-party dependencies.

An OPTIONAL symbolic check of 12 polynomial identities uses SymPy 1.14.0:

    python src/audit_algebra.py

SymPy is not needed by the main replay or the three packaged tests.

The paper is output/pdf/sparse-halves.pdf, with LaTeX source in paper/.
The unmodified official E-JC style is included as paper/e-jc.sty; its
source URL and checksum are in results/ejc-template-source.json.
The manuscript uses the official 12-point layout and theorem styles.
Submission-only metadata avoids unassigned journal volume, dates and DOI.
The numerical certificate in certificates/ belongs to Amir Sarid; its
source and exact version are recorded there. New proof-checking code was
written separately for this research session.

manifest.json lists SHA-256 hashes of the enclosed inputs. A rerun updates
the verification report's timing, so that output file's hash will then
differ from the initial package manifest without changing the proof data.
Public repository: https://github.com/Komeiji-Shiki/erdos-128-sparse-halves
Follow the journal's instructions for delivery of computational supplements.
Initial E-JC submission uses a PDF;
do not substitute this ZIP for the main manuscript or upload LaTeX source
as the initial article file.
