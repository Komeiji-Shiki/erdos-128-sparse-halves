# Sparse halves: revised manuscript and computational materials

The enclosed manuscript proposes the bound 0.02543 n^2. The original
0.02 n^2 problem remains unresolved. This is an AI-assisted draft with no
human mathematical author having checked the complete argument. It has
not been submitted, peer reviewed, or established as an original result.
A subsequent AI-assisted audit of the written proof is recorded in
notes/proof-audit-2026-09-05.md (Chinese). Human author verification is
still required before submission. The intended author name, supplied by the
user, is "komeiji shiki". Contact details and the journal's acceptance of
this pseudonym remain pending.

Run the numerical checks from this directory using Python 3.11 or later:

    python -S src/verify_paper.py

Only the Python standard library is required. This checks five rational
interval certificates using two separate implementations and expands the
cited four-cycle certificate. The second interval implementation imports
no other project modules. Both use exact rational arithmetic. The written
graph-theoretic reductions and the quoted Balogh-Clemen-Lidicky max-cut
and Razborov large-independence theorems remain separate mathematical
obligations. The program explicitly reports its scope.

The second interval checker and the supplied negative-control tests can
also be run separately, without third-party packages:

    python -S src/audit_intervals.py
    python -S -m unittest discover -s tests -v

This focused archive includes three tests; the full research workspace
passed 17 tests. The latter also exercise earlier finite-graph work and
require the workspace's third-party dependencies.

An OPTIONAL symbolic check of 12 polynomial identities uses SymPy 1.14.0:

    python src/audit_algebra.py

SymPy is not needed by the main replay or the three packaged tests.

The paper is output/pdf/sparse-halves.pdf, with LaTeX source in paper/.
The numerical certificate in certificates/ belongs to Amir Sarid; its
source and exact version are recorded there. New proof-checking code was
written separately for this research session.

manifest.json lists SHA-256 hashes of the enclosed inputs. A rerun updates
the verification report's timing, so that output file's hash will then
differ from the initial package manifest without changing the proof data.
The archive has no public URL yet. Follow the journal's instructions for
delivery of computational supplements. Initial E-JC submission uses a PDF;
do not substitute this ZIP for the main manuscript or upload LaTeX source
as the initial article file.
